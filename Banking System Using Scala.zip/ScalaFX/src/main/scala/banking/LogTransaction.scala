package banking
import java.sql.Timestamp
class LogTransaction (transactionId: String, customerId: String, amount: Double, transactionType: String, timestamp: Timestamp){

}
