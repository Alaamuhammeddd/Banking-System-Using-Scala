package banking

object GlobalVariables {
  var isAdmin: Boolean = false
  val adminUsername: String = "admin"
  val adminPassword: String = "admin"
}